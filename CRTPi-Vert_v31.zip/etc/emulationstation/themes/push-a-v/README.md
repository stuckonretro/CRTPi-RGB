Emulationstation Theme: push-a-v

made for 15khz CRTs 320x240px / 240x320px :D vertical setup.  Use pi2scart or pi2jamma to connect your Rpi to a CRT.

* Installation
  * This is installable via RetroPie-Setup

Following cores are supported

arcade
colecovision
fba
mame
megadrive
neogeo

This is a theme made by Asche76. 
